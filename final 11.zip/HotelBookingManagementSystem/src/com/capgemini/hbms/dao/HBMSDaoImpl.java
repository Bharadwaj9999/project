package com.capgemini.hbms.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.hbms.bean.HBMSBookingBean;
import com.capgemini.hbms.bean.HBMSGuestBean;
import com.capgemini.hbms.bean.HBMSHotelBean;
import com.capgemini.hbms.bean.HBMSRoomBean;
import com.capgemini.hbms.bean.HBMSUserBean;
import com.capgemini.hbms.exception.HBMSException;

public class HBMSDaoImpl implements IHBMSDao{
//	InitialContext ic=null;	
//	DataSource ds=null;
//	Connection con=null;
	
	@Override
	public boolean isValidLoginDetails(String username, String password) throws HBMSException {
		try 
		{
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s=con.prepareStatement(IQueryMapper.userValidateQuery);
			s.setString(1, username);
			s.setString(2, password);
			ResultSet st=s.executeQuery();
			st.next();
			int count=st.getInt(1);
			System.out.println(count);
			if(count>0)
			{
				return true;
			}
		}
		catch (SQLException e) 
		{
			throw new HBMSException("error in connection");
		}
		
		return false;
	}

	@Override
	public boolean registerUser(HBMSUserBean b) throws HBMSException {
		try 
		{
			
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s=con.prepareStatement(IQueryMapper.registerUserQuery);
			s.setString(1,b.getPassword());
			s.setString(2,b.getRole());
			s.setString(3,b.getUserName());
			s.setString(4,b.getMobileNo());
			s.setString(5,b.getPhone());
			s.setString(6,b.getAddress());
			s.setString(7,b.getEmail());
			int result=s.executeUpdate();
			if(result!=0)
			{
				return true;
			}
		}
		catch (SQLException e) 
		{
			throw new HBMSException("error in connection");
		}
		return false;
	}

	@Override
	public ArrayList<HBMSHotelBean> getHotelList() throws HBMSException {
		ArrayList<HBMSHotelBean> hotelList=new ArrayList();
		HBMSHotelBean hotel=null;
		try 
		{
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s=con.prepareStatement(IQueryMapper.getHotelListQuery);
			ResultSet rt=s.executeQuery();
			while(rt.next())
			{
				hotel=new HBMSHotelBean();
				hotel.setHotelId(rt.getString(1));
				hotel.setCity(rt.getString(2));
				hotel.setHotelName(rt.getString(3));
				hotel.setAddress(rt.getString(4));
				hotel.setDescription(rt.getString(5));
				hotel.setAvgRatePerNight(rt.getFloat(6));
				hotel.setPhoneNo1(rt.getString(7));
				hotel.setPhoneNo2(rt.getString(8));
				hotel.setRating(rt.getString(9));
				hotel.setEmail(rt.getString(10));
				hotel.setFax(rt.getString(11));
				hotel.setHotelPhoto(rt.getString(12));
				hotelList.add(hotel);
			}
		}
		catch (SQLException e) 
		{
			throw new HBMSException("error in connection");
		}
		return hotelList;
	}

	@Override
	public ArrayList<HBMSRoomBean> getRoomList(String id) throws HBMSException {
		ArrayList<HBMSRoomBean> roomList=new ArrayList();
		HBMSRoomBean room=null;
		try 
		{
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s=con.prepareStatement(IQueryMapper.getRoomListQuery);
			s.setString(1, id);
			ResultSet rt=s.executeQuery();
			while(rt.next())
			{
				room=new HBMSRoomBean();
				room.setHotelId(rt.getString(1));
				room.setRoomId(rt.getString(2));
				room.setRoomNo(rt.getString(3));
				room.setRoomType(rt.getString(4));
				room.setPerNightRate(rt.getFloat(5));
				room.setAvailability(rt.getString(6));
				room.setRoomPhoto(rt.getString(7));
				roomList.add(room);
			}
		}
		catch (SQLException e) 
		{
			throw new HBMSException("error in connection");
		}
		return roomList;
	}

	@Override
	public String getUserId(String username, String password) throws HBMSException {
		try 
		{
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s=con.prepareStatement(IQueryMapper.getUserIdQuery);
			s.setString(1, username);
			s.setString(2, password);
			ResultSet st=s.executeQuery();
			st.next();
			return st.getString(1);
		}
		catch (SQLException e) 
		{
			throw new HBMSException("error in connection");
		}
	}

	@Override
	public float getRoomAmount(String roomId) throws HBMSException {
		try 
		{
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.getRoomAmountQuery);
			s.setString(1, roomId);
			ResultSet re=s.executeQuery();
			re.next();
			return re.getFloat(1);
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public String addBookingDetails(HBMSBookingBean booking) throws HBMSException {
		String bookingId=null;
		try 
		{
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.addBookingDetailsQuery);
			s.setString(1, booking.getRoomId());
			s.setString(2, booking.getUserId());
			s.setDate(3, new Date(booking.getBokkedFrom().getTime()));
			s.setDate(4,new Date(booking.getBookedTo().getTime()));
			s.setInt(5, booking.getNoOfAdults());
			s.setInt(6,booking.getNoOfChildren());
			s.setFloat(7,booking.getAmount());
			s.executeUpdate();
			s=conn.prepareStatement(IQueryMapper.getBookingId);
			ResultSet rt=s.executeQuery();
			rt.next();
			bookingId=rt.getString(1);
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
		return bookingId;
	}

	@Override
	public HBMSBookingBean getBookingDetails(String bookingId) throws HBMSException {
		HBMSBookingBean bean=new HBMSBookingBean();
		try 
		{
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.getBookingDetailsQuery);
			s.setString(1, bookingId);
			ResultSet st=s.executeQuery();
			if(st.next())
			{
				bean.setBookingId(st.getString(1));
				bean.setRoomId(st.getString(2));
				bean.setUserId(st.getString(3));
				bean.setBokkedFrom(st.getDate(4));
				bean.setBookedTo(st.getDate(5));
				bean.setNoOfAdults(st.getInt(6));
				bean.setNoOfChildren(st.getInt(7));
				bean.setAmount(st.getFloat(8));
				return bean;
			}			
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
		return null;
	}

	@Override
	public String addHotelDetails(HBMSHotelBean hotel) throws HBMSException {
		String hotelId=null;
		try {
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			try
			{
				s = conn.prepareStatement(IQueryMapper.hotelAddQuery);
				s.setString(1,hotel.getCity());
				s.setString(2,hotel.getHotelName());
				s.setString(3,hotel.getAddress());
				s.setString(4,hotel.getDescription());
				s.setFloat(5,hotel.getAvgRatePerNight());
				s.setString(6,hotel.getPhoneNo1());
				s.setString(7,hotel.getPhoneNo2());
				s.setString(8,hotel.getRating());
				s.setString(9,hotel.getEmail());
				s.setString(10,hotel.getFax());
				s.setString(11, hotel.getHotelPhoto());
				s.executeUpdate();
				s=conn.prepareStatement(IQueryMapper.getHotelId);
				ResultSet rt=s.executeQuery();
				rt.next();
				hotelId=rt.getString(1);
				return hotelId;
			}
			catch(SQLException e)
			{
				System.out.println(e.getMessage());
			}
			return hotelId;
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public boolean isValidHotelId(String hotelID) throws HBMSException {
		try {
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.validHotelQuery);
			s.setString(1,hotelID);
			ResultSet st=s.executeQuery();
			if(st.next())
			{
				int count=st.getInt(1);
				if(count>0)
				{
					return true;
				}
			}
			return false;
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public ArrayList<HBMSBookingBean> getBookingsOfHotel(String hotelID) throws HBMSException {
		ArrayList<HBMSBookingBean> hotels=new ArrayList<HBMSBookingBean>();
		try {
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.getBookingOfHotelQuery);
			s.setString(1, hotelID);
			ResultSet st=s.executeQuery();
			while(st.next())
			{
				HBMSBookingBean bean=new HBMSBookingBean();
				bean.setBookingId(st.getString(1));
				bean.setRoomId(st.getString(2));
				bean.setUserId(st.getString(3));
				bean.setBokkedFrom(st.getDate(4));
				bean.setBookedTo(st.getDate(5));
				bean.setNoOfAdults(st.getInt(6));
				bean.setNoOfChildren(st.getInt(7));
				bean.setAmount(st.getFloat(8));
				hotels.add(bean);
			}
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
		return hotels;
	}

	@Override
	public boolean deleteHotel(String hotelID) throws HBMSException {
		Connection conn;
		try {
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.getBookedRoomCountQuery);
			s.setString(1, hotelID);
			ResultSet st=s.executeQuery();
			st.next();
			int count=st.getInt(1);
			if(count>0)
			{
				return false;
			}
			s=conn.prepareStatement(IQueryMapper.deleteBookingsOfHotelRoomQuery);
			s.setString(1, hotelID);
			s.executeUpdate();
			s=conn.prepareStatement(IQueryMapper.deleteHotelRoomQuery);
			s.setString(1, hotelID);
			s.executeUpdate();
			s=conn.prepareStatement(IQueryMapper.deleteHotelQuery);
			s.setString(1, hotelID);
			int i=s.executeUpdate();
			System.out.println(i);
		} catch (SQLException e) {
			throw new HBMSException("problem in connecting to database");
			
		}
		return true;
	}

	@Override
	public boolean isValidRoomId(String roomID) throws HBMSException {
		
		try {
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.validRoomQuery);
			s.setString(1,roomID);
			ResultSet st=s.executeQuery();
			if(st.next())
			{
				int count=st.getInt(1);
				if(count>0)
				{
					return true;
				}
			}
			
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
		return false;
	}

	@Override
	public boolean deleteRoom(String roomID) throws HBMSException {
		Connection conn;
		try
		{
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.deleteBookingsOfRoomQuery);
			s.setString(1, roomID);
			s.executeUpdate();
			s=conn.prepareStatement(IQueryMapper.deleteRoomQuery);
			s.setString(1, roomID);
			s.executeUpdate();
		}
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
			
		}
		return true;
	}

	@Override
	public ArrayList<HBMSGuestBean> getGuestListOfHotel(String hotelID) throws HBMSException {
		ArrayList<HBMSGuestBean> list=new ArrayList<HBMSGuestBean>();
		Connection conn;
		try 
		{
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.getGuestListQuery);
			s.setString(1, hotelID);
			ResultSet st=s.executeQuery();
			while(st.next())
			{
				HBMSGuestBean bean=new HBMSGuestBean();
				bean.setUserName(st.getString(1));
				bean.setMobileNumber(st.getString(2));
				bean.setEmail(st.getString(3));
				bean.setBookingId(st.getString(4));
				bean.setRoomId(st.getString(5));
				list.add(bean);
			}
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
			
		}
		
		return list;
	}

	@Override
	public ArrayList<HBMSBookingBean> getBookingsOfSpecifiedDate(java.util.Date bookingDate) throws HBMSException {
		ArrayList<HBMSBookingBean> list=new ArrayList<HBMSBookingBean>();
		Connection conn;
		try 
		{
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.getBookingListQuery);
			s.setDate(1,new Date(bookingDate.getTime()));
			ResultSet st=s.executeQuery();
			while(st.next())
			{
				HBMSBookingBean bean=new HBMSBookingBean();
				bean.setBookingId(st.getString(1));
				bean.setRoomId(st.getString(2));
				bean.setUserId(st.getString(3));
				bean.setBokkedFrom(st.getDate(4));
				bean.setBookedTo(st.getDate(5));
				bean.setNoOfAdults(st.getInt(6));
				bean.setNoOfChildren(st.getInt(7));
				bean.setAmount(st.getFloat(8));
				list.add(bean);
			}
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
			
		}
		return list;
	}

	@Override
	public void checkAvaialbilityStatus() throws HBMSException {
		Connection conn;
		try 
		{
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.checkAvailabilityQuery);
			s.executeUpdate();
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
			
		}
	}

	@Override
	public void changeRoomStatus(String roomid) throws HBMSException {
		Connection conn;
		try 
		{
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.changeStatusQuery);
			s.setString(1,roomid);
			s.executeUpdate();
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
			
		}
	}

	@Override
	public boolean isValidUserName(String userName) throws HBMSException {
		Connection conn;
		try 
		{
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.checkUserNameQuery);
			s.setString(1,userName);
			ResultSet c1=s.executeQuery();
			c1.next();
			int count=c1.getInt(1);
			if(count==0)
			{
				System.out.println("count:"+count);
				return true;
			}
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
			
		}
		return false;
	}

	@Override
	public String addRoomDetails(HBMSRoomBean bean) throws HBMSException {
		try {
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			String roomId=null;
			try
			{
				s = conn.prepareStatement(IQueryMapper.roomAddQuery);
				s.setString(1,bean.getHotelId());
				s.setString(2,bean.getRoomNo());
				s.setString(3,bean.getRoomType());
				s.setFloat(4,bean.getPerNightRate());
				s.setString(5,bean.getAvailability());
				s.setString(6,bean.getRoomPhoto());
				s.executeUpdate();
				s=conn.prepareStatement(IQueryMapper.getRoomId);
				ResultSet rt=s.executeQuery();
				rt.next();
				roomId=rt.getString(1);
				return roomId;
			}
			catch(SQLException e)
			{
				System.out.println(e.getMessage());
			}
			return roomId;
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public void updateRoomType(HBMSRoomBean roomBean) throws HBMSException {
		Connection conn;
		try 
		{
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.updateRoomTypeQuery);
			s.setString(1,roomBean.getRoomType());
			s.setString(2,roomBean.getRoomId());
			s.executeUpdate();
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
			
		}
	}

	@Override
	public void updateRoomRent(HBMSRoomBean roomBean) throws HBMSException {
		Connection conn;
		try 
		{
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.updateRoomRentQuery);
			s.setFloat(1,roomBean.getPerNightRate());
			s.setString(2,roomBean.getRoomId());
			s.executeUpdate();
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
			
		}
	}

	@Override
	public void modifyHotelRating(String hotelID, String rating) throws HBMSException {
		Connection conn;
		try
		{
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.modifyRatingQuery);
			s.setString(1,rating);
			s.setString(2,hotelID);
			int i=s.executeUpdate();
			System.out.println(i+" "+rating+" "+hotelID);
		} 
		catch (SQLException e)
		{
			System.out.println("error");
			throw new HBMSException("problem in connecting to database");
			
		}
	}

	@Override
	public void modifyHotelAvgRate(String hotelId, float avgRate) throws HBMSException {
		Connection conn;
		try {
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.modifyAvgRateQuery);
			s.setFloat(1,avgRate);
			s.setString(2,hotelId);
			s.executeUpdate();
		} catch (SQLException e) {
			throw new HBMSException("problem in connecting to database");
			
		}
	}

	@Override
	public void modifyHotelDescription(String hotelId, String desc) throws HBMSException {
		Connection conn;
		try {
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.modifyDescriptionQuery);
			s.setString(1,desc);
			s.setString(2,hotelId);
			s.executeUpdate();
		} catch (SQLException e) {
			throw new HBMSException("problem in connecting to database");
			
		}
	}

	@Override
	public ArrayList<HBMSBookingBean> getBookingList(String userId) throws HBMSException {
		Connection conn;
		ArrayList<HBMSBookingBean> list=new ArrayList<HBMSBookingBean>();
		try 
		{
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.getBookingsQuery);
			s.setString(1, userId);
			ResultSet st=s.executeQuery();
			while(st.next())
			{
				HBMSBookingBean bean=new HBMSBookingBean();
				bean.setBookingId(st.getString(1));
				bean.setRoomId(st.getString(2));
				bean.setUserId(st.getString(3));
				bean.setBokkedFrom(st.getDate(4));
				bean.setBookedTo(st.getDate(5));
				bean.setNoOfAdults(st.getInt(6));
				bean.setNoOfChildren(st.getInt(7));
				bean.setAmount(st.getFloat(8));
				java.util.Date d=bean.getBokkedFrom();
				java.util.Date d1=new java.util.Date();
				int days=(int) (((d.getTime()-d1.getTime()))/(1000*60*60*24));
				if(days>=3)
				{
					bean.setCancelBooking(true);
				}
				else
				{
					bean.setCancelBooking(false);
				}
				list.add(bean);
			}
		}
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
			
		}
		return list;
	}

	@Override
	public void deleteBooking(String bookingId) throws HBMSException {
		Connection conn;
		try 
		{
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			ResultSet st;
			s=conn.prepareStatement(IQueryMapper.getDeleteBookingRoomIdQuery);
			s.setString(1, bookingId);
			st=s.executeQuery();
			st.next();
			String roomId=st.getString(1);
			s=conn.prepareStatement(IQueryMapper.deleteBookingQuery);
			s.setString(1, bookingId);
			s.executeUpdate();
			s=conn.prepareStatement(IQueryMapper.updateCanceledRoomStatusQuery);
			s.setString(1, roomId);
			s.executeUpdate();
		}
		catch (SQLException e) 
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public String getUserRole(String username, String password) throws HBMSException {
		Connection conn;
		try 
		{
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			ResultSet st;
			s=conn.prepareStatement(IQueryMapper.getUserRoleQuery);
			s.setString(1, username);
			s.setString(2, password);
			st=s.executeQuery();
			st.next();
			return st.getString(1);
		}
		catch (SQLException e) 
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public ArrayList<HBMSBookingBean> getTotalBookingList(String userId) throws HBMSException {
		Connection conn;
		ArrayList<HBMSBookingBean> list=new ArrayList<HBMSBookingBean>();
		try 
		{
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1127", "training1127");
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.getAllBookingDetailsQuery);
			ResultSet st=s.executeQuery();
			while(st.next())
			{
				HBMSBookingBean bean=new HBMSBookingBean();
				bean.setBookingId(st.getString(1));
				bean.setRoomId(st.getString(2));
				bean.setUserId(st.getString(3));
				bean.setBokkedFrom(st.getDate(4));
				bean.setBookedTo(st.getDate(5));
				bean.setNoOfAdults(st.getInt(6));
				bean.setNoOfChildren(st.getInt(7));
				bean.setAmount(st.getFloat(8));
				java.util.Date d=bean.getBokkedFrom();
				java.util.Date d1=new java.util.Date();
				int days=(int) (((d.getTime()-d1.getTime()))/(1000*60*60*24));
				if(days>=3)
				{
					bean.setCancelBooking(true);
				}
				else
				{
					bean.setCancelBooking(false);
				}
				list.add(bean);
			}
		}
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
			
		}
		return list;
	}

}
