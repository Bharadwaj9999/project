package com.capgemini.hbms.exception;

public class HBMSBookingEmployeeException extends Exception {
	String msg;
	public HBMSBookingEmployeeException(String msg)
	{
		this.msg=msg;
	}
	public String toString()
	{
		return this.msg;
	}
}
